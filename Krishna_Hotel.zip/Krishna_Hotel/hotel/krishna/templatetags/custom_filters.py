from django import template

register = template.Library()

@register.filter
def safe_percentage(value, total):
    try:
        return (float(value) / float(total)) * 100 if total > 0 else 0
    except (ValueError, ZeroDivisionError):
        return 0
    
    
@register.filter(name='mask_phone')
def mask_phone(value):
    if value and len(value) > 4:
        return '*' * (len(value) - 4) + value[-4:]
    return value