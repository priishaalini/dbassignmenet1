from django.shortcuts import render ,redirect, get_object_or_404
from django.http import HttpResponse , HttpResponseRedirect
from .models import Hotels,Rooms,Reservation
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
import datetime
import re
import requests
from django.conf import settings
import random
from .models import ForbiddenRequest

# Create your views here.

#homepage
def homepage(request):
    all_location = Hotels.objects.values_list('location','id').distinct().order_by()
    if request.method =="POST":
        try:
            print(request.POST)
            hotel = Hotels.objects.all().get(id=int(request.POST['search_location']))
            rr = []
            
            #for finding the reserved rooms on this time period for excluding from the query set
            for each_reservation in Reservation.objects.all():
                if str(each_reservation.check_in) < str(request.POST['cin']) and str(each_reservation.check_out) < str(request.POST['cout']):
                    pass
                elif str(each_reservation.check_in) > str(request.POST['cin']) and str(each_reservation.check_out) > str(request.POST['cout']):
                    pass
                else:
                    rr.append(each_reservation.room.id)
                
            room = Rooms.objects.all().filter(hotel=hotel,capacity__gte = int(request.POST['capacity'])).exclude(id__in=rr)
            if len(room) == 0:
                messages.warning(request,"Sorry No Rooms Are Available on this time period")
            data = {'rooms':room,'all_location':all_location,'flag':True}
            response = render(request,'index.html',data)
        except Exception as e:
            messages.error(request,e)
            response = render(request,'index.html',{'all_location':all_location})


    else:
        
        
        data = {'all_location':all_location}
        response = render(request,'index.html',data)
    return HttpResponse(response)

#about
def aboutpage(request):
    return HttpResponse(render(request,'about.html'))




def Forbidden(request):
    
    ip_address = '123.45.67.89'
    Resposible_user = request.user.username if request.user.is_authenticated else 'Anonymous'

    ForbiddenRequest.objects.create(
        Resposible_user=Resposible_user,
        ip_address=ip_address
    )

    return HttpResponse(render(request, '403.html'))

def WAF(request):
    
    ip_address = '123.45.67.89'
    Resposible_user = request.user.username if request.user.is_authenticated else 'Anonymous'

    ForbiddenRequest.objects.create(
        Resposible_user=Resposible_user,
        ip_address=ip_address,
        injection_try=True
    )

    return HttpResponse(render(request, 'Detected.html'))
#contact page
def contactpage(request):
    return HttpResponse(render(request,'contact.html'))

def is_password_strong(password):
    if len(password) < 8:
        return False
    if not re.search("[a-z]", password):
        return False
    if not re.search("[A-Z]", password):
        return False
    if not re.search("[0-9]", password):
        return False
    if not re.search("[!@#$%^&*(),.?\":{}|<>]", password):
        return False
    return True


#user sign up
def user_sign_up(request):
    if request.method =="POST":
        user_name = request.POST['username']
        
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        if password1 != password2:
            messages.warning(request,"Password didn't matched")
            return redirect('userloginpage')
        if not is_password_strong(password1):
            messages.error(request, "Password is not strong enough")
            return redirect('userloginpage')
        try:
            if User.objects.all().get(username=user_name):
                messages.warning(request,"Username Not Available")
                return redirect('userloginpage')
        except:
            pass
            

        new_user = User.objects.create_user(username=user_name,password=password1)
        new_user.is_superuser=False
        new_user.is_staff=False
        new_user.save()
        messages.success(request,"Registration Successfull")
        return redirect("userloginpage")
    return HttpResponse('Access Denied')
#staff sign up
def staff_sign_up(request):
    if request.method =="POST":
        user_name = request.POST['username']
        
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        if not is_password_strong(password1):
            messages.error(request, "Password is not strong enough")
            return redirect('staffsignup')
        if password1 != password2:
            messages.success(request,"Password didn't Matched")
            return redirect('staffloginpage')
        try:
            if User.objects.all().get(username=user_name):
                messages.warning(request,"Username Already Exist")
                return redirect("staffloginpage")
        except:
            pass
        
        new_user = User.objects.create_user(username=user_name,password=password1)
        new_user.is_superuser=False
        new_user.is_staff=True
        new_user.save()
        messages.success(request," Staff Registration Successfull")
        return redirect("staffloginpage")
    else:

        return redirect('staffloginpage')
#user login and signup page
def user_log_sign_page(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['pswd']
        recaptcha_response = request.POST.get('g-recaptcha-response')

        # Verify reCAPTCHA
        data = {
            'secret': settings.RECAPTCHA_PRIVATE_KEY,
            'response': recaptcha_response
        }
        r = requests.post('https://www.google.com/recaptcha/api/siteverify', data=data)
        result = r.json()

        if result.get('success'):
            user = authenticate(username=email, password=password)
            if user is not None:
                if user.is_staff:
                    messages.error(request, "Incorrect username or Password")
                    return redirect('staffloginpage')
                else:
                    login(request, user)
                    messages.success(request, "Successful logged in")
                    return redirect('homepage')
            else:
                messages.warning(request, "Incorrect username or password")
        else:
            messages.error(request, "Invalid reCAPTCHA. Please try again.")

    return render(request, 'user/userlogsign.html', {'recaptcha_site_key': settings.RECAPTCHA_PUBLIC_KEY})

#logout for admin and user 
def logoutuser(request):
    if request.method =='GET':
        logout(request)
        messages.success(request,"Logged out successfully")
        print("Logged out successfully")
        return redirect('homepage')
    else:
        print("logout unsuccessfull")
        return redirect('userloginpage')

#staff login and signup page
def staff_log_sign_page(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['pswd']
        recaptcha_response = request.POST.get('g-recaptcha-response')

        # Verify reCAPTCHA
        data = {
            'secret': settings.RECAPTCHA_PRIVATE_KEY,
            'response': recaptcha_response
        }
        r = requests.post('https://www.google.com/recaptcha/api/siteverify', data=data)
        result = r.json()

        if result.get('success'):
            user = authenticate(username=email, password=password)
            if user is not None:
                if user.is_staff:
                    login(request, user)
                    messages.success(request, "Successful logged in")
                    return redirect('homepage')
                else:
                    messages.error(request, "Incorrect username or Password")
                    return redirect('staffloginpage')
            else:
                messages.warning(request, "Incorrect username or password")
        else:
            messages.error(request, "Invalid reCAPTCHA. Please try again.")

    return render(request, 'staff/stafflogsign.html', {'recaptcha_site_key': settings.RECAPTCHA_PUBLIC_KEY})

   

#staff panel page
@login_required(login_url='/staff')
def panel(request):
    
    if request.user.is_staff == False:
        return redirect('Detected')
    
    rooms = Rooms.objects.all()
    total_rooms = len(rooms)
    available_rooms = len(Rooms.objects.all().filter(status='1'))
    unavailable_rooms = len(Rooms.objects.all().filter(status='2'))
    reserved = len(Reservation.objects.all())

    hotel = Hotels.objects.values_list('location','id').distinct().order_by()

    response = render(request,'staff/panel.html',{'location':hotel,'reserved':reserved,'rooms':rooms,'total_rooms':total_rooms,'available':available_rooms,'unavailable':unavailable_rooms})
    return HttpResponse(response)

#for editing room information
@login_required(login_url='/staff')
def edit_room(request):
    if request.user.is_staff == False:   
        return redirect('Detected')
    if request.method == 'POST' and request.user.is_staff:
        print(request.POST)
        old_room = Rooms.objects.all().get(id= int(request.POST['roomid']))
        hotel = Hotels.objects.all().get(id=int(request.POST['hotel']))
        old_room.room_type  = request.POST['roomtype']
        old_room.capacity   =int(request.POST['capacity'])
        old_room.price      = int(request.POST['price'])
        old_room.size       = int(request.POST['size'])
        old_room.hotel      = hotel
        old_room.status     = request.POST['status']
        old_room.room_number=int(request.POST['roomnumber'])

        old_room.save()
        messages.success(request,"Room Details Updated Successfully")
        return redirect('staffpanel')
    else:
    
        room_id = request.GET['roomid']
        room = Rooms.objects.all().get(id=room_id)
        response = render(request,'staff/editroom.html',{'room':room})
        return HttpResponse(response)

#for adding room
@login_required(login_url='/staff')
def add_new_room(request):
    if request.user.is_staff == False:
        
        return redirect('Detected')
    if request.method == "POST":
        total_rooms = len(Rooms.objects.all())
        new_room = Rooms()
        hotel = Hotels.objects.all().get(id = int(request.POST['hotel']))
        print(f"id={hotel.id}")
        print(f"name={hotel.name}")


        new_room.roomnumber = total_rooms + 1
        new_room.room_type  = request.POST['roomtype']
        new_room.capacity   = int(request.POST['capacity'])
        new_room.size       = int(request.POST['size'])
        new_room.capacity   = int(request.POST['capacity'])
        new_room.hotel      = hotel
        new_room.status     = request.POST['status']
        new_room.price      = request.POST['price']

        new_room.save()
        messages.success(request,"New Room Added Successfully")
    
    return redirect('staffpanel')

#booking room page
@login_required(login_url='/user')
def book_room_page(request):
    room = Rooms.objects.all().get(id=int(request.GET['roomid']))
    return HttpResponse(render(request,'user/bookroom.html',{'room':room}))


@login_required(login_url='/staff')
def delete_booking(request, reservation_id):

    if request.user.is_staff==False :
        return redirect('Detected')
        
        
    # Try to get the reservation object
    
    reservation = get_object_or_404(Reservation, booking_id=reservation_id)
    # Perform the cancellation
    reservation.delete()
    # Add a success message
    messages.success(request, "Booking successfully cancelled.")

    # Redirect to a success page or homepage
    return redirect('homepage')

 
@login_required(login_url='/user')
def cancel_booking(request, reservation_id):
    # Get the reservation object or return a 404 error if not found
    reservation = get_object_or_404(Reservation, booking_id=reservation_id, guest=request.user)

    # Check if the reservation is already canceled
    if reservation.status == 'canceled':
        messages.error(request, "This booking is already canceled.")
        return redirect('homepage')  # Redirect to an appropriate page
    if reservation.guest != request.user : 
        messages.error(request, "You don't have the premissions to cancel this booking!.")
        return redirect('homepage')  # Redirect to an appropriate page

    # Perform the cancellation by changing the status
    reservation.status = 'canceled'
    reservation.save()

    # Add a success message
    messages.success(request, "Booking successfully cancelled.")
    # Redirect to a success page or homepage
    return redirect('homepage')


#For booking the room
@login_required(login_url='/user')
def book_room(request):
    
    if request.method =="POST":

        room_id = request.POST['room_id']
        
        room = Rooms.objects.all().get(id=room_id)
        #for finding the reserved rooms on this time period for excluding from the query set
        for each_reservation in Reservation.objects.all().filter(room = room):
            if str(each_reservation.check_in) < str(request.POST['check_in']) and str(each_reservation.check_out) < str(request.POST['check_out']):
                pass
            elif str(each_reservation.check_in) > str(request.POST['check_in']) and str(each_reservation.check_out) > str(request.POST['check_out']):
                pass
            else:
                messages.warning(request,"Sorry This Room is unavailable for Booking")
                return redirect("homepage")
            
        current_user = request.user
        total_person = int( request.POST['person'])
        random_digits = ''.join([str(random.randint(0, 9)) for _ in range(6)])

        reservation = Reservation()
        room_object = Rooms.objects.all().get(id=room_id)
        room_object.status = '2'
        
        user_object = User.objects.all().get(username=current_user)

        reservation.guest = user_object
        reservation.room = room_object
        person = total_person
        reservation.check_in = request.POST['check_in']
        reservation.check_out = request.POST['check_out']
        reservation.booking_id = random_digits + str(room_id)
        reservation.card_name = request.POST.get('card_name', '')
        reservation.card_number = request.POST.get('card_number', '')
        reservation.card_expiry = request.POST.get('card_expiry', '')
        reservation.card_cvv = request.POST.get('card_cvv', '')
        reservation.resident_phone = request.POST.get('resident_phone', '')
        reservation.resident_name = request.POST.get('resident_name', '')
        reservation.approved=False
        reservation.save()

        messages.success(request,"Congratulations! Booking Successfull , waiting for the booking and payment approval .")

        return redirect("homepage")
    else:
        return HttpResponse('Access Denied')

def handler404(request):
    return render(request, '404.html', status=404)

@login_required(login_url='/staff')   
def view_room(request):
    room_id = request.GET['roomid']
    room = Rooms.objects.all().get(id=room_id)

    reservation = Reservation.objects.all().filter(room=room)
    return HttpResponse(render(request,'staff/viewroom.html',{'room':room,'reservations':reservation}))

@login_required(login_url='/user')
def user_bookings(request):
    if request.user.is_authenticated == False:
        return redirect('userloginpage')
    user = User.objects.all().get(id=request.user.id)
    print(f"request user id ={request.user.id}")
    bookings = Reservation.objects.all().filter(guest=user)
    if not bookings:
        messages.warning(request,"No Bookings Found")
    return HttpResponse(render(request,'user/mybookings.html',{'bookings':bookings}))

@login_required(login_url='/staff')
def add_new_location(request):
    if request.method == "POST" and request.user.is_staff:
        owner = request.POST['new_owner']
        location = request.POST['new_city']
        state = request.POST['new_state']
        country = request.POST['new_country']
        
        hotels = Hotels.objects.all().filter(location = location , state = state)
        if hotels:
            messages.warning(request,"Sorry City at this Location already exist")
            return redirect("staffpanel")
        else:
            new_hotel = Hotels()
            new_hotel.owner = owner
            new_hotel.location = location
            new_hotel.state = state
            new_hotel.country = country
            new_hotel.save()
            messages.success(request,"New Location Has been Added Successfully")
            return redirect("staffpanel")

    else:
        return HttpResponse("Not Allowed")


@login_required(login_url='/staff')
def approve(request, reservation_id):
    
    if request.user.is_staff==False :
        return redirect('Detected')
    reservation = get_object_or_404(Reservation, booking_id=reservation_id)
    reservation.approved = True
    reservation.save()
    messages.success(request, "Reservation approved successfully.")
    return redirect('some_view_name')  # Replace with the name of the view to redirect to



#for showing all bookings to staff
@login_required(login_url='/staff')
def all_bookings(request):
   
    bookings = Reservation.objects.all()
    if not bookings:
        messages.warning(request,"No Bookings Found")
    return HttpResponse(render(request,'staff/allbookings.html',{'bookings':bookings}))
    
def delete_room(request, room_id):
    if not request.user.is_staff:
        return redirect('Detected')

    room = get_object_or_404(Rooms, id=room_id)
    room.delete()
    messages.success(request, "Room deleted successfully.")
    return redirect('staffpanel')


        